/**
 * Description: Part of a simple enemy-based Java game using OOP concepts.
 * Author: Sara Al-hachami
 */



// Base class for all enemy types
public abstract class Enemy {

    // Attributes
    private int weight; //  weight (int)
    private int height; //  height (int)

    // A constructor that takes the weight and the height
    public Enemy(int weightVal, int heightVal) {
        weight = weightVal;
        height = heightVal;
    }

    // Gets & Sets weight
    public int getWeight() {
        return weight;
    }
    public void setWeight(int w) {
        weight = w;
    }

    // Gets & Sets height
    public int getHeight() {
        return height;
    }
    public void setHeight(int h) {
        height = h;
    }

    // Abstract method for attack
    public abstract void attack();
}
