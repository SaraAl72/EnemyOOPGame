/**
 * Description: Part of a simple enemy-based Java game using OOP concepts.
 * Author: Sara Al-hachami
 */

import java.util.Random;

// Dragon class in which is an extention of the enemy based class
public class Dragon extends Enemy {

    // Constructor for Dragon
    public Dragon() {
        // Weight is randomly picked between 1000 - 1500
        // Height is randomly picked between 750 - 2000
        super(generateVal(1000, 1500), generateVal(750, 2000));
    }

    // method defines the dragons attack sound
    @Override
    public void attack() {
        System.out.println("Rawr!");
    }

    // Generates a random number within a specific range
    // this is meant for random weight and height generation
    private static int generateVal(int min, int max) {
        Random r = new Random();
        return r.nextInt(max - min + 1) + min;
    }
}
