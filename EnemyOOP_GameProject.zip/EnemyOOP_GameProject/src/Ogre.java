/**
 * Description: Part of a simple enemy-based Java game using OOP concepts.
 * Author: Sara Al-hachami
 */


import java.util.Random;

// This class represents the Ogre enemy type
public class Ogre extends Enemy {

    // Constructor for Ogre
    public Ogre() {

        // Weight is randomly picked between 120 to 200
        // Height is randomly picked between 200 to 300
        super(RNG(120, 200), RNG(200, 300));
    }

    // This is the attack method that prints the Ogres sound
    @Override
    public void attack() {
        System.out.println("Ugh!");
    }

    // method returns a random number between min and max for height or weight
    private static int RNG(int min, int max) {
        Random rand = new Random();
        return rand.nextInt(max - min + 1) + min;
    }
}
