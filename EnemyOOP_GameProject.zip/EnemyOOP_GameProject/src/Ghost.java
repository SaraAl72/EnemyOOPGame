/**
 * Description: Part of a simple enemy-based Java game using OOP concepts.
 * Author: Sara Al-hachami
 */


import java.util.Random;

// This class represents a Ghost enemy

public class Ghost extends Enemy {

    // Constructor for Ghost
    public Ghost() {
        // weight is always 0, height is randomly chosen
        super(0, generateHeight());
    }

    // Ghost's specific attack behavior
    @Override
    public void attack() {
        System.out.println("Boo!");
    }

    // This method picks a random height between 90 and 150
    private static int generateHeight() {
        Random rand = new Random();
        int min = 90;
        int max = 150;
        return rand.nextInt(max - min + 1) + min;
    }
}
