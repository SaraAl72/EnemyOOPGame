/**
 * Description: Part of a simple enemy-based Java game using OOP concepts.
 * Author: Sara Al-hachami
 */


import java.util.Random;

// This class defines the Goblin enemy
public class Goblin extends Enemy {

    // Constructor
    public Goblin() {
        // Weight should be random between 5 and 10
        // Height should be random between 70 and 100
        super(RNG(5, 10), RNG(70, 100));
    }

    // This method defines how a Goblin attacks
    @Override
    public void attack() {
        System.out.println("Gurgle!");
    }

    // Generates a random number between min and max & is used for both weight and height
    private static int RNG(int min, int max) {
        Random r = new Random();
        return r.nextInt(max - min + 1) + min;
    }
}
