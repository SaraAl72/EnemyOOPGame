/**
 * Description: Part of a simple enemy-based Java game using OOP concepts.
 * Author: Sara Al-hachami
 */


import java.util.ArrayList;
import java.util.Random;

// main class that executes the enemy generation and attack simulation
public class EnemyGame {
    public static void main(String[] args) {

        // Creates an ArrayList that can hold any Enemy object
        ArrayList<Enemy> enemies = new ArrayList<>();

        // randomly selects enemy types
        Random rand = new Random();

        // for loop to generate 100 random enemies
        for (int i = 0; i < 100; i++) {
            // Generate a number from 1 to 4
            // RNG result used to decide which enemy to create
            int enemyType = rand.nextInt(4) + 1;

            Enemy e;

            // Based on the number, create the correct enemy type
            switch (enemyType) {
                case 1:
                    e = new Goblin();
                    break;
                case 2:
                    e = new Ghost();
                    break;
                case 3:
                    e = new Ogre();
                    break;
                case 4:
                    e = new Dragon();
                    break;
                default:
                    continue; // This is just in case something unexpected happens
            }

            // Adds the created enemy to the ArrayList
            // Adds each enemy to the list after creation
            enemies.add(e);
        }

        // Loops through the list and calls each enemy's attack method
        for (Enemy e : enemies) {
            e.attack();  // prints out everything
        }
    }
}
